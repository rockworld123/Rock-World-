package id.derysudrajat.alif.data.model

data class LongLat(
    val latitude: Double,
    val longitude: Double,
)
