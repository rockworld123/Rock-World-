package id.derysudrajat.alif.di

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AlifApp : Application()