package id.derysudrajat.alif.data.model

data class Ayah(
    val arabic: String,
    val translate: String,
    val no: Int,
    val roman: String
)
