package id.derysudrajat.alif.data.model

data class RotationTarget(
    val from: Float,
    val to: Float
)
